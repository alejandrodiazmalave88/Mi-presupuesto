// Copia aquí la configuración pública exacta de Firebase Console > Configuración del proyecto > Tus aplicaciones > Config.
export const firebaseConfig = {
  apiKey: "PEGA_AQUI_TU_API_KEY",
  authDomain: "presupuesto-b3729.firebaseapp.com",
  projectId: "presupuesto-b3729",
  appId: "1:674222521783:web:a510e1b5ce194fb2993c32"
};
